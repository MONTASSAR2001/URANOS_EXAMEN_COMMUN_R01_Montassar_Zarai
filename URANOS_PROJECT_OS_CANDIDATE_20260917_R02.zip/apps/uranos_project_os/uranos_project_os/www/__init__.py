"""URANOS authenticated website pages."""
