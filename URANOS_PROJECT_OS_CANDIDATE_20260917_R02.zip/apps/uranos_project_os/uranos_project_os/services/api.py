"""Small role-oriented read models; no native ERP rate-bearing document dumps."""
from __future__ import annotations

from datetime import date
from decimal import Decimal

import frappe

from uranos_project_os import security
from uranos_project_os.services.common import actor, project_rows, scoped_doc

FIELD_ROLES = ("Executive", "Finance Controller", "Engineering Director", "Civil Director", "Electrical Execution Manager",
               "Project Manager", "Site Controller", "Storekeeper", "Procurement Logistics", "QA QC", "HSE", "Team Lead", "Read Only Auditor")


def _json_numbers(value):
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (list, tuple)):
        return [_json_numbers(item) for item in value]
    if isinstance(value, dict):
        return {key: _json_numbers(item) for key, item in value.items()}
    return value


@frappe.whitelist()
def bootstrap():
    from frappe.sessions import get_csrf_token
    user = actor()
    security.require_roles(*FIELD_ROLES)
    projects = frappe.get_list("Project", fields=["name", "project_name", "status"], limit_page_length=500)
    frappe.local.response_headers["Cache-Control"] = "no-store, private"
    return {"user": user, "language": frappe.db.get_value("User", user, "language") or "fr", "csrf_token": get_csrf_token(),
            "roles": [role for role in frappe.get_roles(user) if role.startswith("URANOS ")],
            "projects": projects, "finance_allowed": security.has_financial_access(),
            "server_time": frappe.utils.now(), "environment": frappe.conf.get("uranos_environment", "unclassified")}


@frappe.whitelist()
def project_context(project):
    security.require_roles(*FIELD_ROLES)
    security.require_project(project)
    packages = project_rows("URANOS Work Package", project,
        ["name", "code", "title", "uom", "baseline_version", "status", "modified", "qty_planned", "weight", "discipline"])
    templates = project_rows("URANOS Material Kit Template", project, ["name", "kit_code", "kit_version", "activity", "status"])
    warehouses = project_rows("Warehouse", project, ["name", "warehouse_name", "is_group"])
    profiles = project_rows("URANOS Project Profile", project, ["current_baseline"], limit=2)
    baseline = scoped_doc("URANOS Baseline", profiles[0].current_baseline) if len(profiles) == 1 and profiles[0].current_baseline else None
    active = {row.work_package for row in baseline.packages} if baseline and baseline.status == "Approved" else set()
    issues = project_rows("URANOS Kit Issue", project, ["name", "work_package", "activity", "zone", "crew", "status"])
    reels = project_rows("URANOS Cable Reel", project, ["name", "reel_id", "item_code", "status"])
    return {"project": project, "work_packages": [row for row in packages if row.name in active],
            "kit_templates": [row for row in templates if row.status == "Approved"],
            "warehouses": [row for row in warehouses if not row.is_group],
            "kit_issues": [row for row in issues if row.status in {"Issued", "Partially Used", "Variance Review"}],
            "cable_reels": [row for row in reels if row.status in {"In Use", "Reconciliation"}]}


def _all_rows(doctype, project, fields):
    security.require_project(project, doctype=doctype)
    rows, offset = [], 0
    while True:
        batch = frappe.get_list(doctype, filters={"project": project}, fields=fields,
                                limit_start=offset, limit_page_length=1000, order_by="name asc")
        rows.extend(batch)
        if len(batch) < 1000:
            return rows
        offset += 1000


def _progress(project):
    from uranos_project_os.domain.controls import aggregate_progress, baseline_aliases
    profiles = project_rows("URANOS Project Profile", project, ["name", "current_baseline", "site", "capacity_ac_mw"], limit=2)
    if len(profiles) != 1 or not profiles[0].current_baseline:
        return {"project": project, "physical_progress": None, "work_packages": [], "missing_data": ["approved_baseline"]}
    baseline = scoped_doc("URANOS Baseline", profiles[0].current_baseline)
    if baseline.status != "Approved":
        return {"project": project, "physical_progress": None, "work_packages": [], "missing_data": ["approved_baseline"]}
    packages = [dict(project=project, name=row.work_package, code=row.code, uom=row.uom, baseline_version=baseline.version,
                     qty_planned=row.qty_planned, weight=row.weight, baseline_start=row.baseline_start,
                     baseline_finish=row.baseline_finish) for row in baseline.packages]
    entries = _all_rows("URANOS Field Progress Entry", project,
        ["name", "project", "work_package", "baseline_version", "activity", "zone", "crew", "posting_date",
         "qty_reported", "qty_verified", "reported_by", "verifier", "status", "correction_of", "revision_reason"])
    # One scoped bulk child lookup, not one query per field entry. Parent names
    # originated exclusively from the caller's authorized Project query.
    evidence = {}
    for start in range(0, len(entries), 500):
        parent_names = [row.name for row in entries[start:start + 500]]
        if parent_names:
            for row in frappe.get_all("URANOS Evidence", filters={"parenttype": "URANOS Field Progress Entry", "parent": ["in", parent_names]}, fields=["parent", "file"]):
                evidence.setdefault(row.parent, []).append(row.file)
    for entry in entries:
        entry["evidence"] = evidence.get(entry.name, [])
    approved_versions = [row.version for row in frappe.get_list("URANOS Baseline", filters={"project": project, "status": ["in", ["Approved", "Superseded"]]}, fields=["version"], limit_page_length=0)]
    historical = frappe.get_list("URANOS Work Package", filters={"project": project, "baseline_approved": 1,
        "baseline_version": ["in", approved_versions]}, fields=["name", "project", "code", "uom"], limit_page_length=0)
    current = {"project": project, "version": baseline.version, "packages": packages}
    # Future revision drafts are not official progress. A verified row on an
    # unapproved baseline remains an error, never silently dropped.
    entries = [entry for entry in entries if entry.baseline_version in approved_versions or entry.status == "Verified"]
    return aggregate_progress(project, current, entries, approved_versions=approved_versions,
                              work_package_aliases=baseline_aliases(current, historical))


@frappe.whitelist()
def dashboard(project):
    from uranos_project_os.domain.controls import dashboard_summary
    security.require_roles(*FIELD_ROLES)
    security.require_project(project)
    progress = _progress(project)
    blockers = _all_rows("URANOS Blocker", project, ["name", "project", "title", "status", "severity", "category", "lost_hours"])
    ncrs = _all_rows("URANOS NCR", project, ["name", "project", "status", "severity", "due_date", "defect"])
    if progress["physical_progress"] is None:
        # Unknown baseline never becomes a reassuring zero/green status.
        summary = {"project": project, "physical_progress": None, "planned_progress": None,
                   "material_readiness": None, "status": "Unknown", "missing_data": progress["missing_data"]}
        if (any(row.severity == "Critical" and row.status not in {"Resolved", "Closed"} for row in [*blockers, *ncrs]) or
                any(row.severity == "High" and row.status != "Closed" and row.due_date and frappe.utils.getdate(row.due_date) < date.today() for row in ncrs)):
            summary["status"] = "Red"
    else:
        summary = dashboard_summary(project, progress, blockers=blockers, ncrs=ncrs, today=date.today())
    summary["work_packages"] = progress["work_packages"]
    summary["blockers"] = blockers
    summary["ncrs"] = ncrs
    summary["shipments"] = project_rows("URANOS Shipment", project, ["name", "status", "eta_initial", "eta_revised", "need_by", "criticality"])
    summary["alerts"] = project_rows("URANOS Executive Alert", project, ["name", "rule", "severity", "message", "status", "reference_doctype", "reference_name"])
    # Any live critical alert must remain visible even when other inputs are missing.
    if any(row.status != "Resolved" and (row.severity == "Critical" or row.rule.startswith(
            ("high_risk", "reel_field", "reel_residual"))) for row in summary["alerts"]):
        summary["status"] = "Red"
    elif summary["status"] != "Red" and any(row.status != "Resolved" for row in summary["alerts"]):
        summary["status"] = "Amber"
    if security.has_financial_access():
        summary["costs"] = project_rows("URANOS Project Cost", project,
            ["name", "work_package", "currency", "budget", "committed", "received", "invoiced", "paid", "forecast", "status"])
    summary["as_of"] = frappe.utils.now()
    return _json_numbers(summary)


@frappe.whitelist()
def pending_verifications(project):
    security.require_roles("Site Controller", "QA QC", "Project Manager")
    rows = _all_rows("URANOS Field Progress Entry", project,
        ["name", "work_package", "activity", "zone", "crew", "qty_reported", "reported_by", "posting_date", "status"])
    return [row for row in rows if row.status == "Pending Verification"]


@frappe.whitelist()
def system_health():
    user = actor()
    if "System Manager" not in frappe.get_roles(user):
        frappe.throw("System administration role required", frappe.PermissionError)
    from frappe.utils.scheduler import is_scheduler_inactive
    database = bool(frappe.db.sql("SELECT 1"))
    cache = bool(frappe.cache.ping())
    return {"database": "reachable" if database else "unreachable", "redis": "reachable" if cache else "unreachable",
            "scheduler": "inactive" if is_scheduler_inactive() else "active",
            "backup_restore": "verification_required", "as_of": frappe.utils.now()}
