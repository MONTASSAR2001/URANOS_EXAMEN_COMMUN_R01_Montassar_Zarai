/* Focused Desk actions. Client role hints do not replace server authorization. */
(() => {
  if (window.uranosSupportWorkflowsRegistered) return;
  window.uranosSupportWorkflowsRegistered = true;
  const ar = String(frappe.boot.lang || "fr").startsWith("ar");
  const labels = {
    workflow: ["Actions URANOS", "إجراءات أورانوس"], save: ["Enregistrez le brouillon avant cette action.", "احفظ المسودة قبل هذا الإجراء."],
    confirm: ["Confirmer", "تأكيد"], note: ["Note / justification", "ملاحظة / تبرير"], proof: ["Preuves jointes", "الأدلة المرفقة"],
    file: ["Fichier privé", "ملف خاص"], proofHint: ["Joignez les preuves au document, puis sélectionnez-les ici.", "أرفق الأدلة بالمستند ثم اخترها هنا."],
    analysis: ["Lancer l’analyse d’impact", "بدء تحليل التأثير"], technical: ["Approuver techniquement", "الموافقة الفنية"],
    assess: ["Évaluer le coût", "تقييم التكلفة"], cost: ["Impact coût signé (zéro à confirmer)", "أثر التكلفة بالإشارة (تأكيد الصفر)"],
    policy: ["Politique financière approuvée", "السياسة المالية المعتمدة"], finance: ["Signer la validation financière", "توقيع الموافقة المالية"],
    release: ["Autoriser la mise en œuvre", "السماح بالتنفيذ"], implement: ["Enregistrer la mise en œuvre", "تسجيل التنفيذ"],
    verify: ["Vérifier la mise en œuvre", "التحقق من التنفيذ"], close: ["Clôturer après vérification", "الإغلاق بعد التحقق"],
    reject: ["Rejeter avec motif", "الرفض مع السبب"], submit: ["Figer et soumettre le rapport", "تثبيت التقرير وإرساله"],
    approveReport: ["Approuver le rapport", "اعتماد التقرير"], assign: ["Affecter un responsable", "تعيين مسؤول"],
    user: ["Responsable", "المسؤول"], answer: ["Répondre avec preuves", "الإجابة مع الأدلة"], response: ["Réponse", "الإجابة"],
    resolve: ["Soumettre la résolution", "إرسال الحل"], resolution: ["Résolution constatée", "الحل المنفذ"],
    hours: ["Heures réellement perdues", "ساعات التعطل الفعلية"], review: ["Revoir la sévérité", "مراجعة الخطورة"],
    severity: ["Sévérité", "الخطورة"], waiting: ["Une validation indépendante reste nécessaire.", "لا تزال هناك حاجة إلى موافقة مستقلة."],
    frozen: ["Rapport figé à la soumission", "تقرير ثابت عند الإرسال"], installed: ["Installations vérifiées", "التركيبات المتحقق منها"],
    pending: ["Déclarations en attente", "تصريحات بانتظار التحقق"], moves: ["Mouvements ERP validés", "حركات المخزون المعتمدة"],
    source: ["Référence", "المرجع"], activity: ["Activité / zone", "النشاط / المنطقة"], qty: ["Quantité vérifiée", "الكمية المتحقق منها"],
    approvePolicy: ["Approuver la politique Change Cost", "اعتماد سياسة تكلفة التغيير"],
  };
  const t = key => labels[key][ar ? 1 : 0];
  const roles = (...names) => names.some(name => frappe.user_roles.includes(`URANOS ${name}`));
  const finance = () => roles("Executive", "Finance Controller");
  const engineering = () => roles("Engineering Director");
  const coordinator = () => roles("Engineering Director", "Project Manager", "Site Controller");
  const esc = value => frappe.utils.escape_html(String(value ?? ""));

  function run(frm, service, method, args = {}) {
    if (frm.is_dirty()) return frappe.msgprint(t("save"));
    return frappe.call({method: `uranos_project_os.services.${service}.${method}`, type: "POST",
      args: {name: frm.doc.name, ...args}, freeze: true,
      callback: async ({message}) => {
        if (message?.pending_independent_signature || message?.pending_independent_review) frappe.msgprint(t("waiting"));
        await frm.reload_doc();
      }});
  }

  function prompt(frm, title, fields, callback, evidence = false) {
    if (frm.is_dirty()) return frappe.msgprint(t("save"));
    if (evidence) fields.push({fieldname: "files", label: t("proof"), fieldtype: "Table", reqd: 1,
      description: t("proofHint"), fields: [{fieldname: "file", label: t("file"), fieldtype: "Link", options: "File", reqd: 1, in_list_view: 1}]});
    const dialog = new frappe.ui.Dialog({title, fields, primary_action_label: t("confirm"), primary_action(values) {
      if (evidence) values.evidence_files = (values.files || []).map(row => row.file);
      delete values.files;
      dialog.hide();
      callback(values);
    }});
    dialog.show();
  }

  const note = () => [{fieldname: "note", fieldtype: "Small Text", label: t("note"), reqd: 1}];
  const add = (frm, label, action) => frm.add_custom_button(t(label), action, t("workflow"));
  const change = (frm, status, label, needsNote = false, proof = false) => add(frm, label, () => {
    const perform = args => run(frm, "changes", "transition_change", {status, ...args});
    return needsNote || proof ? prompt(frm, t(label), note(), perform, proof) : perform({});
  });

  frappe.ui.form.on("URANOS Change Request", {refresh(frm) {
    if (frm.is_new()) return;
    const state = frm.doc.status;
    if (state === "Proposed" && roles("Project Manager", "Engineering Director", "Civil Director", "Electrical Execution Manager")) change(frm, "Impact Analysis", "analysis");
    if (["Proposed", "Impact Analysis"].includes(state) && finance()) add(frm, "assess", () => prompt(frm, t("assess"), [
      {fieldname: "cost_impact", fieldtype: "Currency", label: t("cost"), reqd: 1},
      {fieldname: "policy", fieldtype: "Link", options: "URANOS Approval Policy", label: t("policy"), reqd: 1,
        get_query: () => ({filters: {project: frm.doc.project, action: "Change Cost", status: "Approved", enabled: 1}})},
    ], args => run(frm, "changes", "assess_change_cost", args)));
    if (state === "Impact Analysis" && engineering()) change(frm, "Technical Approval", "technical");
    if (state === "Technical Approval" && finance()) change(frm, "Financial Approval", "finance", true);
    if (["Technical Approval", "Financial Approval"].includes(state) && (engineering() || finance())) change(frm, "Approved", "release");
    if (state === "Approved" && roles("Project Manager", "Civil Director", "Electrical Execution Manager", "Engineering Director")) change(frm, "Implemented", "implement", true);
    if (state === "Implemented" && engineering()) change(frm, "Verified", "verify", true, true);
    if (state === "Verified" && engineering()) change(frm, "Closed", "close");
    if (["Proposed", "Impact Analysis", "Technical Approval", "Financial Approval"].includes(state) && roles("Engineering Director", "Project Manager")) change(frm, "Rejected", "reject", true);
  }});

  frappe.ui.form.on("URANOS Approval Policy", {refresh(frm) {
    if (!frm.is_new() && frm.doc.action === "Change Cost" && frm.doc.status === "Draft" && finance())
      add(frm, "approvePolicy", () => run(frm, "changes", "approve_change_policy"));
  }});

  frappe.ui.form.on("URANOS Daily Site Report", {refresh(frm) {
    if (frm.is_new()) return;
    if (frm.doc.status === "Draft" && frm.doc.recorded_by === frappe.session.user && roles("Team Lead", "Site Controller", "Project Manager"))
      add(frm, "submit", () => run(frm, "reports", "submit_daily_report"));
    if (frm.doc.status === "Submitted" && frm.doc.submitted_by !== frappe.session.user && roles("Site Controller", "Project Manager"))
      add(frm, "approveReport", () => run(frm, "reports", "approve_daily_report"));
    for (const field of ["progress_summary", "stock_summary", "blockers_summary", "qa_hse_summary"]) frm.toggle_display(field, false);
    if (!frm.doc.snapshot_at || !frm.fields_dict.snapshot_preview) return;
    try {
      const progress = JSON.parse(frm.doc.progress_summary), stock = JSON.parse(frm.doc.stock_summary);
      const rows = progress.verified_installed || [];
      frm.fields_dict.snapshot_preview.$wrapper.html(`<section dir="${ar ? "rtl" : "ltr"}">
        <h4>${t("frozen")} · ${esc(frm.doc.snapshot_at)}</h4>
        <p>${t("installed")}: ${rows.length} · ${t("pending")}: ${(progress.pending_declarations || []).length} · ${t("moves")}: ${(stock.submitted_erp_movements || []).length}</p>
        <table class="table table-bordered"><thead><tr><th>${t("source")}</th><th>${t("activity")}</th><th>${t("qty")}</th></tr></thead>
        <tbody>${rows.map(row => `<tr><td>${esc(row.name)}</td><td>${esc(row.activity)} / ${esc(row.zone)}</td><td>${esc(row.qty_verified)} ${esc(row.uom)}</td></tr>`).join("")}</tbody></table></section>`);
    } catch { frm.fields_dict.snapshot_preview.$wrapper.text("A COMPLETER"); }
  }});

  frappe.ui.form.on("URANOS RFI", {refresh(frm) {
    if (frm.is_new()) return;
    if (frm.doc.status === "Open" && roles("Engineering Director", "Project Manager")) add(frm, "assign", () => prompt(frm, t("assign"), [
      {fieldname: "assignee", fieldtype: "Link", options: "User", label: t("user"), reqd: 1},
    ], args => run(frm, "reports", "assign_rfi", args)));
    if (frm.doc.status === "Assigned" && frm.doc.assignee === frappe.session.user) add(frm, "answer", () => prompt(frm, t("answer"), [
      {fieldname: "response", fieldtype: "Small Text", label: t("response"), reqd: 1},
    ], args => run(frm, "reports", "answer_rfi", args), true));
    if (frm.doc.status === "Answered" && frm.doc.answered_by !== frappe.session.user && (frm.doc.requester === frappe.session.user || roles("Engineering Director", "Project Manager")))
      add(frm, "close", () => run(frm, "reports", "close_rfi"));
  }});

  frappe.ui.form.on("URANOS Blocker", {refresh(frm) {
    if (frm.is_new()) return;
    if (frm.doc.status === "Open" && coordinator()) add(frm, "assign", () => prompt(frm, t("assign"), [
      {fieldname: "responsible", fieldtype: "Link", options: "User", label: t("user"), reqd: 1},
    ], args => run(frm, "reports", "assign_blocker", args)));
    if (frm.doc.status === "Assigned" && !frm.doc.resolution_submitted_at && frm.doc.responsible === frappe.session.user) add(frm, "resolve", () => prompt(frm, t("resolve"), [
      {fieldname: "resolution", fieldtype: "Small Text", label: t("resolution"), reqd: 1},
      {fieldname: "lost_hours", fieldtype: "Float", label: t("hours"), reqd: 1},
    ], args => run(frm, "reports", "resolve_blocker", args), true));
    if (frm.doc.status === "Assigned" && frm.doc.resolution_submitted_at && frm.doc.resolved_by !== frappe.session.user && coordinator())
      add(frm, "close", () => run(frm, "reports", "close_blocker"));
    if (["Open", "Assigned"].includes(frm.doc.status) && coordinator()) add(frm, "review", () => prompt(frm, t("review"), [
      {fieldname: "severity", fieldtype: "Select", options: ["Low", "Medium", "High", "Critical"], label: t("severity"), reqd: 1},
      {fieldname: "reason", fieldtype: "Small Text", label: t("note"), reqd: 1},
    ], args => run(frm, "reports", "review_blocker_severity", args)));
  }});
})();
