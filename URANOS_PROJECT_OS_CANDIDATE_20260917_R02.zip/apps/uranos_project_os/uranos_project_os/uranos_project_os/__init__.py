"""URANOS native DocTypes."""
